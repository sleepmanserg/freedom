"use strict";

$(document).ready(function () {
    $('.ipos__slider').each(function (key, item) {
        let id = $(this).attr("id");
        let sliderId = '#' + id;
        let appendArrowsClassName = '#' + id + 'slider-controls';
        $(sliderId).slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            autoplay: false,
            dots: false,
            arrows: true,
            appendArrows: (appendArrowsClassName, this),
            prevArrow: '<button class="slide-arrow prev-arrow previous"><svg width="10" height="16" viewBox="0 0 10 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 15L2 8L9 1" stroke="#E6E7E8" stroke-width="2"/></svg></button>',
            nextArrow: '<button class="slide-arrow next-arrow next"><svg width="10" height="16" viewBox="0 0 10 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 1L8 8L1 15" stroke="#E6E7E8" stroke-width="2"/></svg></button>',
            responsive: [{
                    breakpoint: 1100,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        infinite: true
                    }
                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        infinite: true
                    }
                } // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });
    });
});
const isMobile = {
    Android: function () {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function () {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function () {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function () {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function () {
        return navigator.userAgent.match(/IEMobile/i);
    },
    any: function () {
        return isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows();
    }
};

if (isMobile.any()) {
    document.body.classList.add('_isTouch');
} else {
    document.body.classList.add('_isPc');
}
/** Mobile menu toggle */


const iconMenu = document.querySelector('.menu-toggle');
const menuNav = document.querySelector('.main-nav');

if (iconMenu) {
    iconMenu.addEventListener('click', function (e) {
        document.body.classList.toggle('mobileMenu');
        iconMenu.classList.toggle('active');
        menuNav.classList.toggle('active');
    });
}
/** Scroll on nav-link click */


const menuLinks = document.querySelectorAll('.main-nav__link[data-goto]');

if (menuLinks.length > 0) {
    menuLinks.forEach(menuLink => {
        menuLink.addEventListener('click', onMenuLinkClick);
    });

    function onMenuLinkClick(e) {
        const menuLink = e.target;

        if (menuLink.dataset.goto && document.querySelector(menuLink.dataset.goto)) {
            const gotoBlock = document.querySelector(menuLink.dataset.goto);
            const gotoBlockValue = gotoBlock.getBoundingClientRect().top + pageYOffset - document.querySelector('.header__nav').offsetHeight;

            if (iconMenu.classList.contains('active')) {
                document.body.classList.remove('mobileMenu');
                iconMenu.classList.remove('active');
                menuNav.classList.remove('active');
            }

            window.scrollTo({
                top: gotoBlockValue,
                behavior: 'smooth'
            });
            e.preventDefault();
        }
    }
}
/** Header stuck */


const header = document.querySelector('header');
const sectionOne = document.querySelector('.hero-section');
const sectionOneOptions = {
    rootMargin: '-50% 0px 0px 0px'
};
const sectionOneObserver = new IntersectionObserver(function (entries, sectionOneObserver) {
    entries.forEach(entry => {
        if (!entry.isIntersecting) {
            header.classList.add('header-stuck');
        } else {
            header.classList.remove('header-stuck');
        }
    });
}, sectionOneOptions);
sectionOneObserver.observe(sectionOne);